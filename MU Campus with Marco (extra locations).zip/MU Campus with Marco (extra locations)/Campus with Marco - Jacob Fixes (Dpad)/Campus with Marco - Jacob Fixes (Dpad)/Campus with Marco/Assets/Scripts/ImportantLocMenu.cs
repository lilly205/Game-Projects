﻿using UnityEngine;
using System.Collections;

public class ImportantLocMenu : MonoBehaviour {

    public GameObject menu;
    public GameObject menuOpenPos;
    public GameObject menuClosePos;
    public int state = 0;

    // Use this for initialization
    void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    public void OnPlayClick()
    {
        if (state == 0)
        {
            Debug.Log("State now opened");
            menu.transform.position = new Vector3(menuOpenPos.transform.position.x, menu.transform.position.y, menu.transform.position.z);
            state = 1;
            FindObjectOfType<MenuButton>().state = 1;
            FindObjectOfType<MenuButton>().OnPlayClick();
            //FindObjectOfType<MenuButton>().state = 2;
        }
        else if (state == 1)
        {
            Debug.Log("State now closed");
            menu.transform.position = new Vector3(menuClosePos.transform.position.x, menu.transform.position.y, menu.transform.position.z);
            state = 0;
        }
    }
}
