﻿using UnityEngine;
using System.Collections;

public class Rotate : MonoBehaviour
{
    public GameObject target;

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        Vector3 direction = target.transform.position - transform.position;
        direction.Normalize();
        float angle = Mathf.Rad2Deg * Mathf.Atan2(-direction.y, -direction.x);
    

        transform.eulerAngles = new Vector3(0, 0, angle);
    }
}
