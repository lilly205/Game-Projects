﻿using UnityEngine;
using System.Collections;

public class MenuButton2 : MonoBehaviour
{

    public GameObject menu;
    public GameObject menuOpenPos;
    public GameObject menuClosePos;
    public int state = 0;


    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    public void OnPlayClick()
    {
        if (state == 0)
        {
            FindObjectOfType<ImportantLocMenu>().state = 1;
            FindObjectOfType<ImportantLocMenu>().OnPlayClick();
            FindObjectOfType<MenuButton>().state = 0;
            FindObjectOfType<MenuButton>().OnPlayClick();
        }
    }
}

