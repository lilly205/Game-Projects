﻿using UnityEngine;
using System.Collections;

public class MenuButton : MonoBehaviour
{

    public GameObject menu;
    public GameObject menuOpenPos;
    public GameObject menuClosePos;
    public int state = 0;
    public GameObject dpad;

    // Use this for initialization
    void Start ()
    {

    }

    // Update is called once per frame
    void Update ()
    {

    }

    public void OnPlayClick()
    {
        if (state == 0)
        {
            if (FindObjectOfType<ImportantLocMenu>().state == 1)
            {
                FindObjectOfType<ImportantLocMenu>().OnPlayClick();
                dpad.SetActive(true);
            }
            else
            {
                menu.transform.position = new Vector3(menuOpenPos.transform.position.x, menu.transform.position.y, menu.transform.position.z);
                state = 1;
                dpad.SetActive(false);
            }
        }
        else if (state == 1)
        {
            
            menu.transform.position = new Vector3(menuClosePos.transform.position.x, menu.transform.position.y, menu.transform.position.z);
            state = 0;
            if (FindObjectOfType<ImportantLocMenu>().state == 0)
                dpad.SetActive(true);
        }

    }
}

