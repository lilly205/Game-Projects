﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class FaceObject : MonoBehaviour
{
    public GameObject target;
    public GameObject player;

    public Text distanceText;

    private float distance;

	// Use this for initialization
	void Start ()
    { 

	}
	
	// Update is called once per frame
	void Update ()
    {
        distance = Vector3.Distance(player.transform.position, target.transform.position);
        distance = distance * 10;

        if (target.tag != "NullTarget")
        {
            int i = (int)distance;
            distanceText.text = "Distance: " + i;
        }
        if (target != null)
        {
            Vector3 delta = target.transform.position - player.transform.position;
            float angle = Mathf.Atan(delta.y / delta.x);
            angle = Mathf.Atan2(delta.y, delta.x);
            transform.eulerAngles = new Vector3(0, 0, Mathf.Rad2Deg * angle);
        }
        else
            transform.eulerAngles = Vector3.zero;


    }
}
