﻿using UnityEngine;
using System.Collections;

public class PlayerAI : MonoBehaviour
{
    public float speed = 0.1f;

	// Use this for initialization
	void Start ()
    {
	
	}
	
	// Update is called once per frame
	void FixedUpdate ()
    {
        if (Input.GetKey(KeyCode.W))
            transform.Translate(new Vector3(0, speed, 0));
        if (Input.GetKey(KeyCode.A))
            transform.Translate(new Vector3(-speed, 0, 0));
        if (Input.GetKey(KeyCode.S))
            transform.Translate(new Vector3(0, -speed, 0));
        if (Input.GetKey(KeyCode.D))
            transform.Translate(new Vector3(speed, 0, 0));
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            //Exits from Executable
            Application.Quit();
        }

        if (this.gameObject.name == "up")
        {

        }
    }
}
