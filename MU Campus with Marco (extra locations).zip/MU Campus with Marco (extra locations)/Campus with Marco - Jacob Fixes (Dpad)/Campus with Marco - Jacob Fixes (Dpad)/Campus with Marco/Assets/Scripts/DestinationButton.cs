﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class DestinationButton : MonoBehaviour
{

    public GameObject building;
    public Text text;
    public string Name;
    public GameObject star;

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    public void OnPlayClick()
    {
        FindObjectOfType<FaceObject>().target = building;
        FindObjectOfType<Rotate>().target = building;

        star.transform.position = building.transform.position;


            FindObjectOfType<MenuButton>().OnPlayClick();
        

        text.text = "Current Destination: " + Name;
    }
}
