﻿using UnityEngine;
using System.Collections;

public class Down : MonoBehaviour {

    public float speed = 0.1f;
    public GameObject avatar;
    bool touch = false;

    // Use this for initialization
    void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        if (touch == true)
        {
            avatar.transform.Translate(new Vector3(0, -speed, 0));
        }
    }


    public void OnPointerDown()
    {
        touch = true;
    }

    public void OnPointerUp()
    {
        touch = false;
    }

}
