﻿using UnityEngine;
using System.Collections;

public class Left : MonoBehaviour {

    public float speed = 0.1f;
    public GameObject avatar;
    bool touch = false;

    // Use this for initialization
    void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        if (touch == true)
        {
            avatar.transform.Translate(new Vector3(-speed, 0, 0));
        }
    }


    public void OnPointerDown()
    {
        touch = true;
    }

    public void OnPointerUp()
    {
        touch = false;
    }

}
