﻿using UnityEngine;
using System.Collections;

public class Landscape_Mobile : MonoBehaviour {

	// Use this for initialization
	void Start () {
        Screen.orientation = ScreenOrientation.LandscapeLeft;
    }
	
	// Update is called once per frame
	void Update () {
        Screen.orientation = ScreenOrientation.LandscapeLeft;

    }
}
