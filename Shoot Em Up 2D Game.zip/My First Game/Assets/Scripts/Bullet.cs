﻿using UnityEngine;
using System.Collections;

public class Bullet : MonoBehaviour
{
    public int lifeTime = 2;
    public float speed = 10f;
    private float spawnTime;
    public int damage = 20;

    // Use this for initialization
    void Start()
    {
        spawnTime = Time.time;
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(new Vector3(Time.deltaTime * speed, 0, 0));

        //Kill off the bullet 
        if (Time.time - spawnTime > lifeTime)
        {
            //Destroy(this);//this points to the component, Not the gameobject its attached to
            Destroy(gameObject);
        }
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        Debug.Log("Collision!");
        if (collision.gameObject.tag == "Hittable")
        {
            collision.gameObject.SendMessage("TakeDamage", damage);

            Destroy(gameObject);
        }
    }

    void OnTriggerEnter2D(Collider2D col)
    {
        Debug.Log("Triggered!");
    }
}
