﻿using UnityEngine;
using System.Collections;

public class Enemy : MonoBehaviour
{
    public int pointValue = 1;
    public float speed = .1f;

    Vector2 direction;
    float rotation;
    int health;
    Rigidbody2D rb;
    float damage = 20;

    // Use this for initialization
    void Start()
    {
        health = 100;
        direction = new Vector3(-1, 0);
        rb = GetComponent<Rigidbody2D>();
        rb.AddForce(direction * 2100);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void TakeDamage(int dmg)
    {
        health -= dmg;
        if (health <= 0)
        {
            Destroy(gameObject);
            Game gameScript = FindObjectOfType<Game>();
            gameScript.DecrementEnemy();
            gameScript.AddScore(pointValue);
        }
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        Debug.Log("Collision!");
        if (collision.gameObject.tag == "EnemyHittable")
        {
            collision.gameObject.SendMessage("DecreaseHealth", damage);

            Destroy(gameObject);
            Game gameScript = FindObjectOfType<Game>();
            gameScript.DecrementEnemy();
            gameScript.AddScore(pointValue);
        }
    }
}