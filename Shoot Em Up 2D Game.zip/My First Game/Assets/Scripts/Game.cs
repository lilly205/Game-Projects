﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Game : MonoBehaviour
{

    public int maxEnemies = 5;
    public GameObject enemyPrefab;
    private float health = 100;
    public int totalEnemies = 10;


    public Text scoreText;
    public Text healthText;
    public Slider healthBar;
    public Text healthPickup;

    private int numEnemies = 0;
    private float score = 0;

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
            if (maxEnemies < totalEnemies + 1 && numEnemies < maxEnemies) // if the number of max enemies on the screen is less than the total number of enemies, spawn more
            {
                numEnemies++;
                Instantiate(enemyPrefab, new Vector3(10.4f, Random.Range(-4.1f, 3.9f), 0), Quaternion.identity);
            }
            
            if (totalEnemies < 1 && health > 1) // win condition
        {
            SceneManager.LoadScene("Win");
        }

    }

    public void DecrementEnemy()
    {
        numEnemies--;
        totalEnemies--;
    }
    public void AddScore(int kills)
    {
        score += kills; // stores the amount of enemies killed and displays them
        scoreText.text = "Enemies Eliminated: " + score + "/50";
        if (score < 31)
        {
            healthPickup.text = "Health Pickup: " + score + "/30";
            if (score == 30)
            {
                if (health < 100)
                {
                    DecreaseHealth(-20);
                }
                healthPickup.text = "Health Picked Up";
            }
        }
        //Debug.Log(score);
    }
    public void DecreaseHealth(float dmg)
    {
        health -= dmg; // stores health for health bar
        healthBar.value = health/100.0f;
        healthText.text = "Health: " + health + "/100";
        if (health < 1) // lose condition
            SceneManager.LoadScene("Loss");
    }
}