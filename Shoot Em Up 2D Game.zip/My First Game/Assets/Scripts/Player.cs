﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour
{
    public GameObject bullet;
    public float fireRate = 2;//bullets per second

    private float fireTime = float.MinValue;

    // Use this for initialization
    void Start()
    {
        Debug.Log("Player Created");
    }

    void Fire()
    {
        //Shortcircuiting: if we aren't pressing mouse(0), we don't need to check the time
        if (Input.GetMouseButton(0) && Time.time - fireTime > 1 / fireRate)
        {
            fireTime = Time.time;
            GameObject newbullet = (GameObject)Instantiate(bullet, transform.position + transform.right, transform.rotation);
        }
    }

    // Update is called once per frame
    void Update()
    {


        Debug.DrawLine(transform.position, transform.position + transform.right * 10);
        //Debug.DrawLine(Vector3.zero,transform.right * 10);

        if (Input.GetKey(KeyCode.W))
            transform.Translate(new Vector3(0, .1f, 0));
        if (Input.GetKey(KeyCode.S))
            transform.Translate(new Vector3(0, -.1f, 0));


        Fire();
    }
}